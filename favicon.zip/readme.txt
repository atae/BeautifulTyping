Thank you for downloading a favicon from Free Favicon! This favicon was created from an image at http://openclipart.org/ and converted to a favicon and other sizes for you to use in your projects. For more details about this image visit this page: https://openclipart.org/detail/173594/Firework

For more infomation about how you can use this image from OpenClipArt see this page: http://openclipart.org/may-clipart-be-used-comparison

Here are the contents of this compressed package:

*  favicon.ico  --  The favicon file (supports both 16*16 and 32*32 dimensions). You will need to rename this to favicon.ico and upload to your web site.

  * You can add a favicon to your web page by uploading favicon.ico to Root of your  website and inserting the following HTML tag between the <head> ... </head> tags of your web page.

<link rel="shortcut icon" href="favicon.ico" /> 

* There are many different sized png files for use a icons for smartphones, tablets and desktop use.  

If you are having any problems installing your favicon we have tips on the Free Favicon blog. http://www.freefavicon.com/blog/

Thank you once again for download from Free Favicon! If you like your favicon we appreciate you taking the time to mention our service to others, blogging about us and of course by linking to us.

We also encourage you to check out Backblaze online backup. We use Backblaze to backup our computers and keep our data safe. They offer a free 15 day trial and are the easiest online backup service we have used.

Use this link http://www.freefavicon.com/blog/outgoing/backblaze.php to try Backblaze for Free!

By signing up for Backblaze you help keep Free Favicon free!

Thank you,
FreeFavicon.com